-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2018 at 05:51 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `list_book`
--

CREATE TABLE `list_book` (
  `id_lb` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `list_book`
--

INSERT INTO `list_book` (`id_lb`, `title`, `author`, `category`, `price`) VALUES
(14, 'Matematika Discrete', 'Tati Ernawati', 'Informatika', 250000),
(15, 'Struktur Data', 'Wali Muhammad', 'Informatika', 300000),
(16, 'Code Igniter Basic', 'Dadan Saepul Ramdan', 'Informatika', 300000),
(17, 'Database Object', 'Aris Rismayana', 'Informatika', 400000),
(18, 'Office Tools', 'Arie Sudrajat', 'Informatika', 250000),
(19, 'Game Programming', 'Rikman Rudawan', 'Informatika', 350000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `list_book`
--
ALTER TABLE `list_book`
  ADD PRIMARY KEY (`id_lb`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `list_book`
--
ALTER TABLE `list_book`
  MODIFY `id_lb` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
