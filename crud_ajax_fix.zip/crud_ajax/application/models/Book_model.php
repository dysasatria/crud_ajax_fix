<?php
/**
* 
*/
class Book_model extends CI_Model
{

	var $table="list_book";

	function book_add($data){//berfungsi untuk INSERT data ke dalam database
		$this->db->insert($this->table, $data);
		return $this->db->insert_id(); 
	}

	function get_allBooks(){//berfungsi untuk GET data dari database
		$this->db->from("list_book");
		$query = $this->db->get();
		return $query->result();
	}

	function get_byId($id){
		$this->db->from($this->table);
		$this->db->where('id_lb', $id);
		$query = $this->db->get();

		return $query->row();
	}

	function update_book($where, $data){
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	function delete_byId($id){
		$this->db->where('id_lb',$id);
		$this->db->delete($this->table);
	}
}